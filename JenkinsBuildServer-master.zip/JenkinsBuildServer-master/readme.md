
[Jenkins Home](https://jenkins.io/doc/book/pipeline/jenkinsfile/)
[Docker Swarm Docs](https://docs.docker.com/engine/swarm/)
[Docker Registry](https://docs.docker.com/registry/)
[Jenkins + Docker Swarm](https://www.nielsvandermolen.com/continuous-integration-jenkins-docker/)
[Jenkins for Windows + Linux + Mac](https://medium.com/@Joachim8675309/jenkins-environment-using-docker-6a12603ebf9)

[Docker Swarm Docs](https://docs.docker.com/engine/swarm/)
[Docker Registry](https://docs.docker.com/registry/)
[Docker + Jenkins + Behat example](https://code-maze.com/ci-jenkins-docker/)

[Similar Setup](https://github.com/eea/eea.docker.jenkins)
[Groovy Scripts](https://github.com/cloudbees/jenkins-scripts)
[Groovy Scripts](https://github.com/peterjenkins1/jenkins-scripts)
